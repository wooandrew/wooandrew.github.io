#pragma once

#ifndef CONTAINER
#define CONTAINER

#include <string>

int __cdecl parasite(void);
int __cdecl host(int argc, char **argv);

#endif // !CONTAINER
