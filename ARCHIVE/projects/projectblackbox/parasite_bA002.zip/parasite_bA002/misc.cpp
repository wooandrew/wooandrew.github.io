// misc functions for Project BlackBox: Parasite

#include "misc.h"
