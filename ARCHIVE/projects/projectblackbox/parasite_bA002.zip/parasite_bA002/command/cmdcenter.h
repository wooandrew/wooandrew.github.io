#pragma once

#ifndef COMMAND_CENTER_HOST
#define COMMAND_CENTER_HOST

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <cstdio>

#include <windows.h>
#include <strsafe.h>
#include <dwmapi.h>

#pragma comment(lib, "dwmapi.lib")

bool SetForegroundWindowInternal(HWND hWnd);

BOOL CALLBACK EnumWindowsProcAll(HWND hWnd, LPARAM lParam);
BOOL CALLBACK EnumWindowsProcVisible(HWND hWnd, LPARAM lParam);
BOOL CALLBACK EnumWindowsProcReduced(HWND hWnd, LPARAM lParam);

void keystroke(std::string input);
std::string media(std::string action, std::string other);

std::string cc_input(std::string str_input);

#endif // !COMMAND_CENTER_HOST
