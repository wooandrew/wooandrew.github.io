// Project BlackBox _ Parasite (c) Andrew Woo, 2019
// MISC functions for parasite/server

#include "paramisc.h"
#include <cstdio>

void gen_help() {

	printf("\nUsage: help command");
	printf("\nEnter 'exit' to quit.");
	printf("\n");
	printf("\nCommands:");
	printf("\n get_windows       Returns running applications");
	printf("\n switch_windows    Brings specified window to foreground.");
	printf("\n keystroke         Synthesizes keystrokes");
	printf("\n media             Controls media options");
	printf("\n");
}

void gw_help() {

	printf("\nUsage: get_windows -option");
	printf("\nReturns running applications");
	printf("\n");
	printf("\nOptions:");
	printf("\n -a      Returns running applications");
	printf("\n -v      Returns all visible windows");
	printf("\n -r      Returns reduced results (DWMWA_CLOAKED = false)");
	printf("\n");
	printf("\nDefault option: -r");
	printf("\n");
}

void sw_help() {

	printf("\nUsage: switch_windows window title");
	printf("\nBrings specified window to foreground.\n");
}

void ks_help() {

	printf("\nUsage: keystroke -option EnteR a Valid string..!");
	printf("\nSynthesizes keystrokes");
	printf("\n");
	printf("\nThis function is incomplete.");
	printf("\n");
	printf("\nOptions:");
	printf("\n -k      Set keyboard as input mode");
	printf("\n -m      Set mouse as input mode");
	printf("\n ");
	printf("\n-m options:");
	printf("\n [m1]    Left mouse button");
	printf("\n [m2]    Right mouse button");
	printf("\n [m3]    Middle mouse button");
	printf("\n [mx]    Mouse button x");
	printf("\n ");
}

void media_help() {

	printf("\nUsage: media action other");
	printf("\nControls media options");
	printf("\n");
	printf("\nThis is a Windows only command.");
	printf("\n");
	printf("\nActions:");
	printf("\n mute      Mutes device");
	printf("\n unmute    Unmutes device");
	printf("\n stop      Stops media playback");
	printf("\n play      Resumes media playback                   UNRELIABLE");
	printf("\n pause     Pauses media playback                    UNRELIABLE");
	printf("\n next      Plays next track");
	printf("\n prev      Plays previous track");
	printf("\n v_up      Synthesizes volume step up");
	printf("\n v_down    Synthesizes volume step down");
	printf("\n v_set     Set volume (ex. v_set 20)");
	printf("\n");
}
