// Project BlackBox _ Parasite (c) Andrew Woo, 2019
// Email: seungminleader@gmail.com

/* Version: bA003
 * Role: Server (listen for connection)
 * Role in Symbiotic Relationship: Parasite << send instructions
 * System: Windows
 */

#undef UNICODE

#define WIN32_LEAN_AND_MEAN
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include "misc.h"
#include "parasite-server/paramisc.h"

#include <iostream>
#include <string>
#include <sstream>
#include <vector>

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <cstdlib>
#include <cstdio>

#pragma comment (lib, "Ws2_32.lib")

#define DEFAULT_BUFLEN 10238976
#define DEFAULT_PORT "27015"

// int __cdecl main(void) {
int __cdecl parasite(void) {

	system("TITLE Parasite");

	std::cin.ignore();

	std::vector<std::string> v_input;

	WSADATA wsaData;
	int iResult;

	SOCKET ListenSocket = INVALID_SOCKET;
	SOCKET ClientSocket = INVALID_SOCKET;

	SOCKADDR_IN addr;
	int addrlen = sizeof(addr);

	struct addrinfo *result = NULL;
	struct addrinfo hints;

	int iSendResult;
	char recvbuf[DEFAULT_BUFLEN] = {};
	int recvbuflen = DEFAULT_BUFLEN;

	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed with error: %d\n", iResult);
		return 1;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;

	// Resolve the server address and port
	iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
	if (iResult != 0) {

		printf("getaddrinfo failed with error: %d\n", iResult);
		WSACleanup();

		return 1;
	}

	// Create a SOCKET for connecting to server
	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (ListenSocket == INVALID_SOCKET) {

		printf("socket failed with error: %ld\n", WSAGetLastError());
		freeaddrinfo(result);

		WSACleanup();

		return 1;
	}

	// Setup the TCP listening socket
	iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
	if (iResult == SOCKET_ERROR) {

		printf("bind failed with error: %d\n", WSAGetLastError());
		freeaddrinfo(result);
		closesocket(ListenSocket);

		WSACleanup();

		return 1;
	}

	freeaddrinfo(result);

	iResult = listen(ListenSocket, SOMAXCONN);
	if (iResult == SOCKET_ERROR) {

		printf("Listen failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);

		WSACleanup();

		return 1;
	}
	else {

		printf(R"(  _____                    _ _       )"); printf("\n");
		printf(R"( |  __ \                  (_) |      )"); printf("\n");
		printf(R"( | |__) |_ _ _ __ __ _ ___ _| |_ ___ )"); printf("\n");
		printf(R"( |  ___/ _` | '__/ _` / __| | __/ _ \)"); printf("\n");
		printf(R"( | |  | (_| | | | (_| \__ \ | ||  __/)"); printf("\n");
		printf(R"( |_|   \__,_|_|  \__,_|___/_|\__\___|)"); printf("\n");
		printf("\n");
		printf(" Listening for connection...\n");
	}

	// Accept a client socket
	ClientSocket = accept(ListenSocket, (SOCKADDR*)&addr, &addrlen);
	if (ClientSocket == INVALID_SOCKET) {

		printf("accept failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);

		WSACleanup();

		return 1;
	}
	else {
		system("CLS");
		printf(R"(  _____                    _ _       )"); printf("\n");
		printf(R"( |  __ \                  (_) |      )"); printf("\n");
		printf(R"( | |__) |_ _ _ __ __ _ ___ _| |_ ___ )"); printf("\n");
		printf(R"( |  ___/ _` | '__/ _` / __| | __/ _ \)"); printf("\n");
		printf(R"( | |  | (_| | | | (_| \__ \ | ||  __/)"); printf("\n");
		printf(R"( |_|   \__,_|_|  \__,_|___/_|\__\___|)"); printf("\n");
		printf("\n");
		std::cout << " Client Accepted! @ " << (char*)inet_ntoa(addr.sin_addr) << "\n" << std::endl;
	}

	// No longer need server socket
	closesocket(ListenSocket);

	// *** SEND DATA ******************************************************************************************************* //
	while (true) {

		std::string input = "";

	inputMethod:

		printf(">>> ");
		getline(std::cin, input);

		v_input.clear();

		std::string buf;
		std::stringstream ss(input);
		while (ss >> buf) {
			v_input.push_back(buf);
		}

		if (input == "") {
			goto inputMethod;
		}
		else if (v_input[0] == "exit") {
			printf("\n");
			break;
		}

		if (v_input[0] == "help") {

			if (v_input.size() < 2) {
				gen_help();
			}
			else if (v_input[1] == "get_windows") {
				gw_help();
			}
			else if (v_input[1] == "switch_windows") {
				sw_help();
			}
			else if (v_input[1] == "keystroke") {
				ks_help();
			}
			else if (v_input[1] == "media") {
				media_help();
			}
			else {
				printf("Usage: help command\n");
			}

			printf("\n");
			goto inputMethod;
		}

		if (v_input[0] == "keystroke") {
			input = "keystroke" + ReadKeystroke();
			FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
			printf("\n");
		}

		iSendResult = send(ClientSocket, input.c_str(), input.length(), 0);
		if (iSendResult == SOCKET_ERROR) {
			printf("Send failed with error: %d\n", WSAGetLastError());
		}

		iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);
		if (iResult > 0) {

			printf("\nBytes received: %d\n", iResult);
			std::string srecvbuf = recvbuf;
			std::cout << srecvbuf << std::endl;

			ZeroMemory(recvbuf, recvbuflen);
		}
		else if (iResult == 0) {
			printf("\nNo bytes recieved.\n");
		}
		else {
			printf("\nrecv failed with error: %d\n", WSAGetLastError());
			closesocket(ClientSocket);
			WSACleanup();

			return 1;
		}

		printf("\n");
	}
	// *** SEND DATA ******************************************************************************************************* //

	// *** SHUTDOWN ******************************************************************************************************** //
	iResult = shutdown(ClientSocket, SD_SEND);
	if (iResult == SOCKET_ERROR) {

		printf("shutdown failed with error: %d\n", WSAGetLastError());
		closesocket(ClientSocket);
		WSACleanup();

		return 1;
	}

	closesocket(ClientSocket);
	WSACleanup();
	// *** SHUTDOWN ******************************************************************************************************** //

	// *** RECV DATA ******************************************************************************************************* // END
	do {
		iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);

		if (iResult > 0) {

			printf("Bytes received: %d\n", iResult);
			std::string srecvbuf = recvbuf;
			std::cout << srecvbuf << std::endl;

			ZeroMemory(recvbuf, recvbuflen);
		}
		else if (iResult == 0) {
			printf("Connection closed\n\n");
		}
		else {
			printf("recv failed with error: %d\n", WSAGetLastError());
		}

	} while (iResult > 0);
	// *** RECV DATA ******************************************************************************************************* // END

	return 0;
}
