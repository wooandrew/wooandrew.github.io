Project BlackBox _ Parasite (c) Andrew Woo, 2019
Email: seungminleader@gmail.com

******************************************************
Start Date: February 7, 2019
End Date: TBD

newest version: BUILD variant bA003
stable version: \0
******************************************************

************************************************************************************************************************************************************************
 DISCLAIMER
  This project is strictly for educational purposes. All 'tools' built through this project
  were strictly deployed to devices with owner consent for the sole purpose of testing and 
  learning. No nefarious and/or illegal activities were carried out using these 'tools.'

 LICENSE - Woo Open Source License v1
  Copyright (c) Andrew Woo, 2019

  1. Definition
     "Tools" shall be defined as any program, including source variant, that is developed through this project.
     "Project" shall be defined as the wrapper containing all tools and files necessary for the proper function of tools.
     "Creator" shall be defined as the original writer(s) of the project.
     "Contributor" shall be defined anyone who willingly assists in the development of the project, or modifies a derivation of the project.
     "User(s)" shall be defined as the individual(s) who employ(s) the project and its tools.

  2. Right of ownership
     This project is expressly open source. Any derivation of the project and its individual tools, modified or otherwise, must thus also be open source.
     This project is owned by the public. It may not be sold or rented for any price at any time.
     Derivations of the project and its individual tools must credit the creator and all contributors.
     A copy of this license must accompany all copies and derivations of the project and tools.

  3. Right to use
     Anyone may use this project and its tools within the constraints of the law.
     All owners, creators, and contributors, are not liable for the actions of the user. The actions of the user are therefore strictly the user's responsibility.
     Unless directly linked, no individual other than the creator is liable to any crime or action carried out henceforth.
  
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
************************************************************************************************************************************************************************

Purpose:
 The purpose of this tool is to discreetly access, control, and steal from a remote device.

Sub-Tools:
 windows_host		(client/host)
 windows_parasite	(server/parasite)

Commands:
  
COMMAND                                     WORKS ON OS?                        FUNCTION
get_windows                                 Windows                             Returns running applications
switch_windows                              Windows                             Brings specified window to foreground.
keystroke                                   Windows                             Synthesizes keystrokes
media                                       Windows                             Controls media options
