// Project BlackBox _ Parasite (c) Andrew Woo, 2019
// MISC functions for parasite/server

#include "paramisc.h"

#include <cstdio>
#include <sstream>
#include <windows.h>

void gen_help() {

	printf("\nUsage: help command");
	printf("\nEnter 'exit' to quit.");
	printf("\n");
	printf("\nParasite : Version bA003");
	printf("\n");
	printf("\nCommands:");
	printf("\n get_windows       Returns running applications");
	printf("\n switch_windows    Brings specified window to foreground.");
	printf("\n keystroke         Synthesizes keystrokes");
	printf("\n media             Controls media options");
	printf("\n");
}

void gw_help() {

	printf("\nUsage: get_windows -option");
	printf("\nReturns running applications");
	printf("\n");
	printf("\nOptions:");
	printf("\n -a      Returns running applications");
	printf("\n -v      Returns all visible windows");
	printf("\n -r      Returns reduced results (DWMWA_CLOAKED = false)");
	printf("\n");
	printf("\nDefault option: -r");
	printf("\n");
}

void sw_help() {

	printf("\nUsage: switch_windows window title");
	printf("\nBrings specified window to foreground.\n");
}

void ks_help() {

	printf("\nUsage: keystroke");
	printf("\nSynthesizes keystrokes");
	printf("\n ");
}

void media_help() {

	printf("\nUsage: media action other");
	printf("\nControls media options");
	printf("\n");
	printf("\nThis is a Windows only command.");
	printf("\n");
	printf("\nActions:");
	printf("\n mute      Mutes device");
	printf("\n unmute    Unmutes device");
	printf("\n stop      Stops media playback");
	printf("\n play      Resumes media playback                   UNRELIABLE");
	printf("\n pause     Pauses media playback                    UNRELIABLE");
	printf("\n next      Plays next track");
	printf("\n prev      Plays previous track");
	printf("\n v_up      Synthesizes volume step up");
	printf("\n v_down    Synthesizes volume step down");
	printf("\n v_set     Set volume (ex. v_set 20)");
	printf("\n");
}

std::string ReadKeystroke() {

	printf("\nWaiting 5 seconds...\n");

	Sleep(5000);

	printf("\nReading keystrokes:~$ ...\nEscape sequence: CTRL+ALT+Right\n\n");

	short int shiftdown = 0;
	bool shiftsent = false;

	short int ctrldown = 0;
	bool ctrlsent = false;

	short int altdown = 0;
	bool altsent = false;

	short int windown = 0;
	bool winsent = false;

	unsigned short u, i;

	bool readkeystroke = true;

	std::string input = "";
	std::stringstream inhex;

	while (readkeystroke) { // Infinite Loop

		u = 1;
		while (u < 250 && readkeystroke) {

			for (i = 0; i < 50; i++, u++) {

				if (((GetKeyState(VK_CONTROL) & 0x8000) || (GetKeyState(VK_LCONTROL) & 0x8000) || (GetKeyState(VK_RCONTROL) & 0x8000)) &&
					((GetKeyState(VK_MENU) & 0x8000) || (GetKeyState(VK_LMENU) & 0x8000) || (GetKeyState(VK_RMENU) & 0x8000)) && (GetKeyState(VK_RIGHT) & 0x8000)) {

					readkeystroke = false;

					break;
				}

				if (GetAsyncKeyState(u) == -32767) { // Read Keystrokes

					if (u == VK_SHIFT || u == VK_LSHIFT || u == VK_RSHIFT) { // SHIFTDOWN

						shiftdown = GetKeyState(u);

						if ((shiftdown & 0x8000) && !shiftsent) {
							shiftsent = true;
							printf(" [shift]");
							input = input + " [shift]";
						}

						continue;
					}
					else if (u == VK_CONTROL || u == VK_LCONTROL || u == VK_RCONTROL) { // CTRLDOWN

						ctrldown = GetKeyState(u);

						if ((ctrldown & 0x8000) && !ctrlsent) {
							ctrlsent = true;
							printf(" [ctrl]");
							input = input + " [ctrl]";
						}

						continue;
					}
					else if (u == VK_MENU || u == VK_LMENU || u == VK_RMENU) { // ALTDOWN

						altdown = GetKeyState(u);

						if ((altdown & 0x8000) && !altsent) {
							altsent = true;
							printf(" [alt]");
							input = input + " [alt]";
						}

						continue;
					}
					else if (u == VK_LWIN || u == VK_RWIN) { // WINDOWN

						windown = GetKeyState(u);

						if ((windown & 0x8000) && !winsent) {
							winsent = true;
							printf(" [win]");
							input = input + " [win]";
						}

						continue;
					}

					if (!(GetKeyState(VK_LSHIFT) & 0x8000) && !(GetKeyState(VK_RSHIFT) & 0x8000) && shiftsent) { // SHIFTUP
						shiftsent = false;
						printf(" [!shift]");
						input = input + " [!shift]";
					}
					else if (!(GetKeyState(VK_LCONTROL) & 0x8000) && !(GetKeyState(VK_RCONTROL) & 0x8000) && ctrlsent) { // CTRLUP
						ctrlsent = false;
						printf(" [!ctrl]");
						input = input + " [!ctrl]";
					}
					else if (!(GetKeyState(VK_LMENU) & 0x8000) && !(GetKeyState(VK_RMENU) & 0x8000) && altsent) { // ALTUP
						altsent = false;
						printf(" [!alt]");
						input = input + " [!alt]";
					}
					else if (!(GetKeyState(VK_LWIN) & 0x8000) && !(GetKeyState(VK_RWIN) & 0x8000) && winsent) { // WINUP
						winsent = false;
						printf(" [!win]");
						input = input + " [!win]";
					}

					if (u != 16 && u != 17 && u != 18) {

						printf(" 0x%02x", u);

						inhex << " 0x" << std::hex << u;
						input = input + inhex.str();
						inhex.str(std::string());
					}
				}
			}

			Sleep(1);
		}
	}

	return input;
}
