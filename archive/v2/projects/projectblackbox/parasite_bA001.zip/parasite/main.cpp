// Parasite _ main.cpp
// This is for testing purposes only.

#include <iostream>
#include <string>

#include "main.h"

int main(int argc, char **argv) {

	bool run = true;
	std::string mode = "";

	while (run) {

		std::cout << "Enter mode: ";
		std::cin >> mode;

		if (mode == "parasite") {
			parasite();
		}
		else if (mode == "host") {

			std::string ipaddr = "";
			
			std::cout << "Enter IPv4 Address: ";	// get from ipconfig on Windows
			std::cin.ignore();
			getline(std::cin, ipaddr);

			argv[0] = (char*)"host";
			argv[1] = (char*)ipaddr.c_str();

			std::cout << "\nAttempting to connect to: " << argv[1] << std::endl;

			host(2, argv);
		}
		else if (mode == "exit") {
			run = false;
		}
	}
	
	return 0;
}
