// Directory.h _ main.cpp :: Andrew Woo (c) 2017
// seungminleader@gmail.com

#include <iostream>
#include "directory.h"
#include <string>

using namespace std;

int main(){
	
	string path = dir.getDir();
	
    cout << "Your current path is: " << path << endl << endl;

	system("SLEEP");
	
    return 0;
}
