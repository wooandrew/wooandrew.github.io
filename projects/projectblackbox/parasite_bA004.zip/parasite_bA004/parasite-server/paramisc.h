#pragma once

#ifndef PARASITE_MISC_FUNC
#define PARASITE_MUSC_FUNC

#include <string>

void gen_help();
void gw_help();
void sw_help();
void ks_help();
void media_help();
void ss_help();

std::string ReadKeystroke();

#endif // !PARASITE_MISC_FUNC
