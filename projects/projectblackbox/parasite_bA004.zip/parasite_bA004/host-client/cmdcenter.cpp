// Project BlackBox: Parasite (c) Andrew Woo, 2019
// Email: seungminleader@gmail.com

/*
 * Parasite Command Center -> host (client)
 * Carries out commands sent by -> parasite (server)
 */

#include "cmdcenter.h"

#include <gdiplus.h>

#pragma comment(lib, "gdiplus.lib")

using namespace Gdiplus;

#include <mmdeviceapi.h>
#include <endpointvolume.h>

#define MAX_TITLE_LEN 500

std::vector<std::string> titles;

std::string cc_input(std::vector<std::string> input) {

	std::string ret = "";

	if (input[0] == "get_windows") {

		if (input.size() > 1) {

			if (input[1] == "-a") {
				EnumWindows(EnumWindowsProcAll, reinterpret_cast<LPARAM>(&titles));
			}
			else if (input[1] == "-v") {
				EnumWindows(EnumWindowsProcVisible, reinterpret_cast<LPARAM>(&titles));
			}
			else if (input[1] == "-r") {
				EnumWindows(EnumWindowsProcReduced, reinterpret_cast<LPARAM>(&titles));
			}
		}
		else {
			EnumWindows(EnumWindowsProcReduced, reinterpret_cast<LPARAM>(&titles));
		}

		for (unsigned int x = 0; x < titles.size(); x++) {
			ret = ret + "\nget_windows $~ " + titles[x];
		}

		titles.clear();

		char foregroundWindowTitle[512];
		GetWindowText(::GetForegroundWindow(), foregroundWindowTitle, sizeof(foregroundWindowTitle));

		ret = ret + "\n\nForeground Window:~ " + foregroundWindowTitle;

		return ret;
	}
	else if (input[0] == "switch_windows") {

		std::string windowTitle = input[1];

		for (unsigned int x = 2; x < input.size(); x++) {
			windowTitle = windowTitle + " " + input[x];
		}

		HWND hWnd = ::FindWindow(NULL, windowTitle.c_str());
		if (hWnd) {

			if (SetForegroundWindowInternal(hWnd)) {
				return "Switched foreground to:~ " + windowTitle;
			}
			else {
				return "Fatal Error:~ Failed to switch foreground.";
			}
		}
		else {
			return "Fatal Error:~ Could not find " + windowTitle;
		}
	}
	else if (input[0] == "keystroke") {

		HWND hWnd = ::FindWindow(NULL, "*new 1 - Notepad++");

		SetForegroundWindowInternal(hWnd);

		Sleep(1000);

		return keystroke(input);
	}
	else if (input[0] == "media") {

		if (input.size() > 2) {
			return media(input[1], input[2]);
		}
		else {
			return media(input[1], "");
		}
	}
	else {
		return "Fatal Error:~ Unknown command: " + input[0];
	}

	return "Fatal error:~ xxx";
}

bool SetForegroundWindowInternal(HWND hWnd) {
	
	if (!::IsWindow(hWnd)) {
		return false;
	}

	BYTE keyState[256] = { 0 };
	
	if (::GetKeyboardState((LPBYTE)&keyState)) {
		if (!(keyState[VK_MENU] & 0x80)) {
			::keybd_event(VK_MENU, 0, KEYEVENTF_EXTENDEDKEY | 0, 0); // keybd_event deprecated, update necessary (to SendInput())
		}
	}

	::SetForegroundWindow(hWnd);

	if (::GetKeyboardState((LPBYTE)&keyState)) {
		if (!(keyState[VK_MENU] & 0x80)) {
			::keybd_event(VK_MENU, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0); // keybd_event deprecated, update necessary (to SendInput())
		}
	}

	return true;
}

BOOL CALLBACK EnumWindowsProcAll(HWND hWnd, LPARAM lParam) {

	char windowTitle[512];

	GetWindowText(hWnd, windowTitle, sizeof(windowTitle));

	if ((int)*windowTitle == 0) {
		return true;
	}
	titles.push_back(windowTitle);

	return true;
}

BOOL CALLBACK EnumWindowsProcVisible(HWND hWnd, LPARAM lParam) {

	char windowTitle[512];

	GetWindowText(hWnd, windowTitle, sizeof(windowTitle));
	if (!IsWindowVisible(hWnd)) {
		return true;
	}
	if ((int)*windowTitle == 0) {
		return true;
	}
	titles.push_back(windowTitle);

	return true;
}

BOOL CALLBACK EnumWindowsProcReduced(HWND hWnd, LPARAM lParam) {

	LONG lStyle = GetWindowLongPtrW(hWnd, GWL_STYLE);

	if ((lStyle & WS_VISIBLE) && (lStyle & WS_SYSMENU))
	{
		CONST CHAR CRLF[2] = { '\r', '\n' };
		HANDLE hFile = *(HANDLE *)lParam;
		DWORD dwWritten;
		CHAR szTitle[MAX_TITLE_LEN];
		HRESULT hr;
		UINT uLen;
		INT nCloaked;

		DwmGetWindowAttribute(hWnd, DWMWA_CLOAKED, &nCloaked, sizeof(INT));
		if (nCloaked) {
			return true;
		}

		GetWindowTextA(hWnd, szTitle, MAX_TITLE_LEN);
		hr = StringCbLengthA(szTitle, MAX_TITLE_LEN, &uLen);
		if (SUCCEEDED(hr) && uLen > 0)
		{
			SetFilePointer(hFile, 0, NULL, FILE_END);
			WriteFile(hFile, szTitle, uLen, &dwWritten, NULL);
			WriteFile(hFile, CRLF, 2, &dwWritten, NULL);

			titles.push_back(szTitle);
		}
	}

	return true;
}

std::string keystroke(std::vector<std::string> input) {

	std::string ret = "Synthesized keystrokes.";
	
	INPUT in;

	for (unsigned int h = 1; h < input.size() - 2; h++) {

		if (input[h] == "[shift]") {

			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY;
			in.ki.wVk = VK_SHIFT;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "[!shift]") {

			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP;
			in.ki.wVk = VK_SHIFT;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "[ctrl]") {
			
			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP;
			in.ki.wVk = VK_LCONTROL;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "[!ctrl]") {

			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP;
			in.ki.wVk = VK_LCONTROL;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "[alt]") {

			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP;
			in.ki.wVk = VK_MENU;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "[!alt]") {

			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP;
			in.ki.wVk = VK_MENU;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "[win]") {

			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP;
			in.ki.wVk = VK_LWIN;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "[!win]") {

			in.type = INPUT_KEYBOARD;

			in.ki.wScan = NULL;
			in.ki.dwFlags = KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP;
			in.ki.wVk = VK_LWIN;

			SendInput(1, &in, sizeof(INPUT));
			Sleep(15);

			continue;
		}
		else if (input[h] == "0x01" || input[h] == "0x02" || input[h] == "0x04" || input[h] == "0x05" || input[h] == "0x06") {
			
			in.type = INPUT_MOUSE;

			ret = "Synthesized keystrokes with errors: ignored mouse input.";

			continue;
		}

		in.type = INPUT_KEYBOARD;
		in.ki.wScan = NULL;
		in.ki.dwFlags = NULL;

		in.ki.wVk = (int)strtol(input[h].c_str(), 0, 16);

		SendInput(1, &in, sizeof(INPUT));
		Sleep(15);
	}

	return ret;
}

std::string media(std::string action, std::string other) {

	HRESULT hr;

	CoInitialize(NULL);
	IMMDeviceEnumerator *deviceEnumerator = NULL;
	hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), NULL, CLSCTX_INPROC_SERVER, __uuidof(IMMDeviceEnumerator), (LPVOID *)&deviceEnumerator);
	IMMDevice *defaultDevice = NULL;

	hr = deviceEnumerator->GetDefaultAudioEndpoint(eRender, eConsole, &defaultDevice);
	deviceEnumerator->Release();
	deviceEnumerator = NULL;

	IAudioEndpointVolume *endpointVolume = NULL;
	hr = defaultDevice->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_INPROC_SERVER, NULL, (LPVOID *)&endpointVolume);
	defaultDevice->Release();
	defaultDevice = NULL;

	if (action == "mute") {

		endpointVolume->SetMute(true, NULL);

		endpointVolume->Release();
		CoUninitialize();

		return "media :~: Device muted.";
	}
	else if (action == "unmute") {

		endpointVolume->SetMute(false, NULL);

		endpointVolume->Release();
		CoUninitialize();

		return "media :~: Device unmuted.";
	}
	else if (action == "stop") {

		INPUT in;
		in.type = INPUT_KEYBOARD;
		in.ki.wScan = 0;
		in.ki.time = 0;
		in.ki.dwExtraInfo = 0;
		in.ki.dwFlags = 0;

		in.ki.wVk = 0xB2;
		SendInput(1, &in, sizeof(INPUT));

		return "media :~: Media playback stopped.";
	}
	else if (action == "play") {

		INPUT in;
		in.type = INPUT_KEYBOARD;
		in.ki.wScan = 0;
		in.ki.time = 0;
		in.ki.dwExtraInfo = 0;
		in.ki.dwFlags = 0;

		in.ki.wVk = 0xB3;
		SendInput(1, &in, sizeof(INPUT));

		return "media :~: Media playback resumed.";
	}
	else if (action == "pause") {

		INPUT in;
		in.type = INPUT_KEYBOARD;
		in.ki.wScan = 0;
		in.ki.time = 0;
		in.ki.dwExtraInfo = 0;
		in.ki.dwFlags = 0;

		in.ki.wVk = 0xB3;
		SendInput(1, &in, sizeof(INPUT));

		return "media :~: Media playback paused.";
	}
	else if (action == "next") {
		
		INPUT in;
		in.type = INPUT_KEYBOARD;
		in.ki.wScan = 0;
		in.ki.time = 0;
		in.ki.dwExtraInfo = 0;
		in.ki.dwFlags = 0;

		in.ki.wVk = 0xB0;
		SendInput(1, &in, sizeof(INPUT));

		return "media :~: Switched to next track.";
	}
	else if (action == "prev") {

		INPUT in;
		in.type = INPUT_KEYBOARD;
		in.ki.wScan = 0;
		in.ki.time = 0;
		in.ki.dwExtraInfo = 0;
		in.ki.dwFlags = 0;

		in.ki.wVk = 0xB1;
		SendInput(1, &in, sizeof(INPUT));
		Sleep(5);
		SendInput(1, &in, sizeof(INPUT));

		return "media :~: Switched to previous track.";
	}
	else if (action == "v_up") {

		endpointVolume->VolumeStepUp(NULL);

		endpointVolume->Release();
		CoUninitialize();

		return "media :~: Synthesized volume step up.";
	}
	else if (action == "v_down") {

		endpointVolume->VolumeStepDown(NULL);

		endpointVolume->Release();
		CoUninitialize();

		return "media :~: Synthesized volume step down.";
	}
	else if (action == "v_set") {
	
		hr = endpointVolume->SetMasterVolumeLevelScalar(static_cast<float>(stof(other) / 100), NULL);

		endpointVolume->Release();
		CoUninitialize();

		if (hr == E_INVALIDARG) {
			return "media :~: Invalid argument [" + other + "]. Enter value between 0-100.";
		}
		else {
			return "media :~: Volume set to " + other + ".";
		}
	}

	endpointVolume->Release();
	CoUninitialize();

	return "Fatal error:~ Unknown action " + action;
}

int GetEncoderClsid(const wchar_t *format, CLSID *pClsid) {

	unsigned int num = 0;
	unsigned int size = 0;
	
	GetImageEncodersSize(&num, &size);
	
	if (size == 0) {
		return -1;
	}
	
	ImageCodecInfo *pImageCodecInfo = (ImageCodecInfo *)(malloc(size));
	if (pImageCodecInfo == NULL) return -1;
	GetImageEncoders(num, size, pImageCodecInfo);

	for (unsigned int j = 0; j < num; ++j) {

		if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0) {
			
			*pClsid = pImageCodecInfo[j].Clsid;
			free(pImageCodecInfo);

			return j;
		}
	}

	free(pImageCodecInfo);

	return -1;
}

// --- NOT MY CODE - BY NAPALM ----------------------------------------------------------------------- //
int SaveScreenshot(std::string filename, ULONG uQuality) {

	ULONG_PTR gdiplusToken;
	GdiplusStartupInput gdiplusStartupInput;
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
	HWND hMyWnd = GetDesktopWindow();
	RECT r;
	int w;
	int h;
	HDC dc, hdcCapture;
	int nBPP;
	int nCapture;
	int iRes;
	LPBYTE lpCapture;
	CLSID imageCLSID;
	Bitmap *pScreenShot;

	// get the area of my application's window    
	GetWindowRect(hMyWnd, &r);
	dc = GetWindowDC(hMyWnd);
	w = r.right - r.left;
	h = r.bottom - r.top;
	nBPP = GetDeviceCaps(dc, BITSPIXEL);
	hdcCapture = CreateCompatibleDC(dc);

	// create the buffer for the screenshot
	BITMAPINFO bmiCapture = { sizeof(BITMAPINFOHEADER), w, -h, 1, nBPP, BI_RGB, 0, 0, 0, 0, 0 };

	// create a container and take the screenshot
	HBITMAP hbmCapture = CreateDIBSection(dc, &bmiCapture, DIB_PAL_COLORS, (LPVOID*)&lpCapture, NULL, 0);

	// failed to take it
	if (!hbmCapture) {

		DeleteDC(hdcCapture);
		DeleteDC(dc);
		GdiplusShutdown(gdiplusToken);
		printf("Error: Failed to take screenshot %d\n", GetLastError());
		
		return 0;
	}

	// copy the screenshot buffer
	nCapture = SaveDC(hdcCapture);
	SelectObject(hdcCapture, hbmCapture);
	BitBlt(hdcCapture, 0, 0, w, h, dc, 0, 0, SRCCOPY);
	RestoreDC(hdcCapture, nCapture);
	DeleteDC(hdcCapture);
	DeleteDC(dc);

	// save the buffer to a file  
	pScreenShot = new Bitmap(hbmCapture, (HPALETTE)NULL);
	EncoderParameters encoderParams;
	encoderParams.Count = 1;
	encoderParams.Parameter[0].NumberOfValues = 1;
	encoderParams.Parameter[0].Guid = EncoderQuality;
	encoderParams.Parameter[0].Type = EncoderParameterValueTypeLong;
	encoderParams.Parameter[0].Value = &uQuality;
	GetEncoderClsid(L"image/jpeg", &imageCLSID);

	wchar_t *lpszFilename = new wchar_t[filename.length() + 1];
	mbstowcs(lpszFilename, filename.c_str(), filename.length() + 1);

	iRes = (pScreenShot->Save(lpszFilename, &imageCLSID, &encoderParams) == Ok);
	delete pScreenShot;
	DeleteObject(hbmCapture);
	GdiplusShutdown(gdiplusToken);

	return iRes;
}
// --- NOT MY CODE - BY NAPALM ----------------------------------------------------------------------- //
